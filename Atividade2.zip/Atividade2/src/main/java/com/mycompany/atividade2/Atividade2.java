/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade2;

/**
 *
 * @author aluno
 */
public class Atividade2 {

    public static void main(String[] args) {
        new FrameAtividade2().setVisible(true);
    }
}
